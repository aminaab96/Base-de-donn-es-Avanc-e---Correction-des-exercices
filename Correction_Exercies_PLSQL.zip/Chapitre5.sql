-------------------------Chapitre 5---------------------------------
-------Exercice 1
--------1)
--Les exceptions d�finies par le syst�me et celles d�finies par l�utilisateur sont toutes deux des types d�exceptions.
--------2)
--� l�aide de la commande RAISE, on peut facilement lever une exception de mani�re explicite. Les utilisateurs peuvent explicitement lever une exception en utilisant l�instruction RAISE ou DBMS_STANDARD.RAISE_APPLICATION_ERROR.
--------3)
--DECLARE myexception EXCEPTION; est la syntaxe des exceptions d�finies par l�utilisateur.
--------4)
--L'avantage de l'utilisation des execption c'est qu'ils :
----Prot�gent l�utilisateur contre les erreurs
----Prot�gent la base de donn�es contre les erreurs
----Les erreurs majeures prennent beaucoup de ressources syst�me
--------5)
--1.Lorsque SELECT INTO ne renvoie aucune ligne, l�exception pr�d�finie NO_DATA_FOUND est lev�e.
--2.L�exception ACCESS_INTO_NULL se produit Lorsque l�attribution automatique d�une valeur � un objet NULL.
--3.Une exception qui se produit lors d�une tentative d�acc�s � une base de donn�es sans s�y connecter est NOT_LOGGED_ON.
--4.PROGRAM_ERROR est affich� lorsqu�il y a un probl�me interne dans PL/SQL.
--5.L�exception ZERO_DIVIDE appara�t lorsqu�un nombre est divis� par z�ro.
-------Exercice 2
--------1)
CREATE OR REPLACE PROCEDURE CHERECHE_AQUARIUM (i_aqua IN aquarium.id_aquarium%TYPE, nom_aqua OUT VARCHAR2, taille_aqua OUT NUMBER)
AS
BEGIN
    SELECT nom, taille INTO nom_aqua, taille_aqua FROM Aquarium
    WHERE id_aquarium = i_aqua;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Aucune donn�e pour cet ID: ' || i_aqua);
END CHERECHE_AQUARIUM;
-- Demandez � l'utilisateur de saisir l'id de l'aquarium
ACCEPT N_ID PROMPT 'Veuillez saisir l''id de l''aquarium :'
DECLARE
    i_aqua NUMBER := &N_ID;
    taille NUMBER;
    nom VARCHAR(50);
BEGIN
    CHERECHE_AQUARIUM(i_aqua, nom,taille);
    DBMS_OUTPUT.PUT_LINE(RPAD('Nom de l''aquarium : ',20) || RPAD(nom,10) || RPAD(' Taille : ',10)|| taille );
END;
--------2)
CREATE OR REPLACE PROCEDURE NOMBRE_POISSONS
( ES_Date IN VARCHAR2, NB_ESPECE OUT INTEGER,NB_POISSON OUT INTEGER)
IS
RECORD_NOT_EXISTS EXCEPTION;
BEGIN
    SELECT COUNT(DISTINCT(id_espece)), COUNT(id_poisson)
    INTO NB_ESPECE, NB_POISSON
    FROM Poisson 
    WHERE date_naissance > TO_DATE(ES_Date, 'DD/MM/YYYY ');
    IF NB_ESPECE = 0 THEN
        RAISE RECORD_NOT_EXISTS;
    END IF;
EXCEPTION
    WHEN RECORD_NOT_EXISTS THEN
    DBMS_OUTPUT.PUT_LINE('Pas de poissons qui sont n�s apr�s le : ' || ES_Date);
END NOMBRE_POISSONS;
-- Demandez � l'utilisateur de saisir la date souhait�e
ACCEPT ES_DATE PROMPT 'Veuillez saisir une date :'
DECLARE
    es_date VARCHAR(50) := '&ES_DATE';
    nombre_e NUMBER; 
    nombre_p NUMBER; 
BEGIN
    NOMBRE_POISSONS(es_date,nombre_e, nombre_p );
    DBMS_OUTPUT.PUT_LINE('Il existe '|| nombre_p || ' poissons qui sont n�s apr�s le : ' || es_date || ' appartenant � : ' || nombre_e || ' especes');
END;
-------Exercice 3
--------1)
--ORA-01422: exact fetch returns more than requested number of rows
--------2)
-- Demandez � l'utilisateur de saisir la date souhait�e
ACCEPT ES_DATE PROMPT 'Veuillez saisir une date :'
DECLARE
    id_poissons poisson.id_poisson%TYPE;
    es_date VARCHAR(50) := '&ES_DATE';
BEGIN
    SELECT id_poisson
    INTO id_poissons
    FROM Poisson
    WHERE date_naissance = es_date;
EXCEPTION
    WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE ('Trop de lignes retourn�s par la requ�te');
END;
--------3)
-- Demandez � l'utilisateur de saisir la date souhait�e
ACCEPT ES_DATE PROMPT 'Veuillez saisir une date :'
DECLARE
    id_poissons poisson.id_poisson%TYPE;
    es_date VARCHAR(50) := '&ES_DATE';
BEGIN
    SELECT id_poisson
    INTO id_poissons
    FROM Poisson
    WHERE date_naissance = es_date;
EXCEPTION
    WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE ('Trop de lignes retourn�s par la requ�te');
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE ('Pas de naissances pour la date s�lectionn�e');
END;
--------4)
-- Demandez � l'utilisateur de saisir la date souhait�e
ACCEPT ES_DATE PROMPT 'Veuillez saisir une date :'
DECLARE
   es_date VARCHAR(50) := '&ES_DATE'; -- Date de recherche
   v_NomEspece Espece.nom_scientifique%TYPE;
   v_NomPoisson Poisson.nom%TYPE;
   
   CURSOR MonCurseur IS
   SELECT E.nom_scientifique as nom_espece, P.nom as nom_poisson
    INTO v_NomEspece, v_NomPoisson
    FROM Poisson P
    JOIN Espece E
    ON P.id_espece = E.id_espece
    WHERE date_naissance = TO_DATE(ES_Date, 'DD/MM/YYYY ');
    
    cursor_poisson MonCurseur%ROWTYPE;
BEGIN
   OPEN MonCurseur;
   FETCH MonCurseur INTO cursor_poisson;
   IF MonCurseur%NOTFOUND THEN
      DBMS_OUTPUT.PUT_LINE('Aucune naissance de poissons trouv�e pour la date ' || es_date);
   ELSE
      DBMS_OUTPUT.PUT_LINE('Esp�ces ayant eu des naissances � la date ' || ES_Date || ':');
      LOOP
         EXIT WHEN MonCurseur%NOTFOUND;
         DBMS_OUTPUT.PUT_LINE(RPAD('Nom de l''esp�ce : ',20) || RPAD(cursor_poisson.nom_espece,20) || '||' || RPAD(' Nom du poisson : ',20)|| cursor_poisson.nom_poisson );
         FETCH MonCurseur INTO cursor_poisson;       
      END LOOP;
   END IF;
   CLOSE MonCurseur;
END;
-------Exercice 4
--------1)
DECLARE
    DATE_DONNEE DATE := '01/12/2012';
    CURSOR C IS SELECT nom, date_naissance FROM Poisson;
BEGIN
    FOR i IN C
    LOOP
        IF i.date_naissance < DATE_DONNEE THEN
            RAISE_APPLICATION_ERROR (-20005,'Date de naissance post�rieure � la date donn�e !');
        ELSE
            DBMS_OUTPUT.PUT_LINE(i.nom||'est n� le'||i.date_naissance);
        END IF;
    END LOOP;
END;
--------2)
DECLARE
    DATE_DONNEE DATE := '01/12/2022';
    CURSOR C IS SELECT nom, date_naissance FROM Poisson;
    
    INVALID_POISSON_DATES EXCEPTION;
    PRAGMA EXCEPTION_INIT(INVALID_POISSON_DATES,-20005);
BEGIN
    FOR i IN C
    LOOP
        IF i.date_naissance < DATE_DONNEE THEN
            RAISE INVALID_POISSON_DATES;
        ELSE
            DBMS_OUTPUT.PUT_LINE(i.nom||'est n� le'||i.date_naissance);
        END IF;
    END LOOP;
EXCEPTION
    WHEN INVALID_POISSON_DATES THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM||'Date de naissance post�rieure � la date donn�e !');
END;