-------------------------Chapitre 7---------------------------------
-------Exercice 1
--------1)
--Les d�clencheurs en PL/SQL sont des blocs de code qui sont automatiquement ex�cut�s en r�ponse � des �v�nements sp�cifiques, tels que des op�rations de modification (INSERT, UPDATE, DELETE) ou de lecture (SELECT) sur une table. Ils sont utiles pour automatiser des t�ches, appliquer des r�gles m�tier, effectuer des v�rifications d'int�grit� des donn�es, g�n�rer des journaux d'audit, etc.
--------2)
--Pour sp�cifier le nom de la table associ�e � un d�clencheur en PL/SQL, vous pouvez utiliser la clause ON table_name apr�s le nom du d�clencheur. 
--------3)
--Les op�rations SQL qui peuvent d�clencher l'ex�cution d'un trigger en PL/SQL sont principalement les op�rations de modification de donn�es LMD (Lecture, Modification, et Suppression) sur une table, ce qui permet de prendre des mesures sp�cifiques en fonction des �v�nements.. Cependant, il existe �galement des d�clencheurs de type BEFORE SELECT qui peuvent �tre utilis�s pour des op�rations de lecture.
--------4)
--La clause sp�cifique dans la syntaxe des d�clencheurs PL/SQL qui indique que le d�clencheur est ex�cut� pour chaque ligne affect�e par l'instruction SQL est FOR EACH ROW. En utilisant cette clause, vous pouvez vous assurer que le d�clencheur agit sur chaque enregistrement individuellement.
--------5)
--Pour r�f�rencer � la fois la nouvelle valeur ins�r�e (NEW) et l'ancienne valeur (OLD) dans un enregistrement lorsque vous travaillez avec des d�clencheurs en PL/SQL, vous pouvez utiliser les pr�fixes : :NEW pour la nouvelle valeur et :OLD pour l'ancienne valeur. 
-------Exercice 2
--------1)
CREATE OR REPLACE TRIGGER monTrigger1
    AFTER INSERT ON Poisson
BEGIN
    DBMS_OUTPUT.PUT_LINE('Insertion valid�e');
END;
--------2)
CREATE OR REPLACE TRIGGER monTrigger2
    BEFORE UPDATE OF NOM_SCIENTIFIQUE ON ESPECE
FOR EACH ROW
BEGIN
   DBMS_OUTPUT.PUT_LINE('Confirmation de mise � jour');
END;
--------3)
CREATE OR REPLACE TRIGGER monTrigger3
    AFTER UPDATE OF taille on Aquarium
FOR EACH ROW
BEGIN
   DBMS_OUTPUT.PUT_LINE('Nouveau: ' || :new.taille);
   DBMS_OUTPUT.PUT_LINE('Ancien: ' || :old.taille);
END;
UPDATE Aquarium SET taille = taille - 450 WHERE id_aquarium=3;
-------Exercice 3
CREATE OR REPLACE TRIGGER VerifArrivagePoisson
BEFORE UPDATE OF taille ON Aquarium
FOR EACH ROW
DECLARE
    v_capacite_aquarium NUMBER;
    es_taille Aquarium.taille%TYPE;
    Nb_poisson NUMBER;
BEGIN
    
    SELECT A.taille, COUNT(P.id_poisson) AS Nombre_Poissons
    INTO es_taille, Nb_poisson
    FROM aquarium A
    JOIN Poisson P ON A.id_aquarium = p.id_aquarium
    WHERE A.id_aquarium = :NEW.id_aquarium
    GROUP BY A.Nom, A.taille
    ORDER BY COUNT(P.id_poisson) DESC;
    -- R�cup�rer la capacit� totale du aquarium

    IF (:NEW.id_aquarium IS NOT NULL) THEN
        IF :NEW.taille < Nb_poisson THEN
            -- Annuler l'insertion et afficher un message d'erreur
            RAISE_APPLICATION_ERROR(-20001, 'Impossible de diminuer la taille ! Nombre de poissons sup�rieur � la nouvelle taille.');
        END IF;
    END IF;
END;
-------Exercice 4
--------1)
CREATE OR REPLACE TRIGGER V�rificatioAquarium
BEFORE INSERT ON AQUARIUM
FOR EACH ROW /* n�cessaire pour avoir acc�s � :NEW */
DECLARE
MaxTaille AQUARIUM.taille%TYPE;
BEGIN
SELECT MAX(taille) INTO MaxTaille
FROM AQUARIUM;
IF tailleTotale > :NEW.taille THEN
    RAISE_APPLICATION_ERROR(-20100, 'Taille d''aquarium inferieur � la taille maximale des aquariums existants :' || MaxTaille);
END IF;
END;
--------2)
CREATE OR REPLACE PROCEDURE UPDATEXIST(new_nom IN Aquarium.nom%TYPE, new_taille IN Aquarium.taille%TYPE)
AS
     PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    DBMS_OUTPUT.PUT_LINE(new_nom || '-----------------' || new_taille);
     UPDATE Aquarium
        SET taille = new_taille
        WHERE nom = new_nom; 
     COMMIT;
END;
CREATE OR REPLACE TRIGGER INSAQUARIUM
BEFORE INSERT ON Aquarium
FOR EACH ROW
DECLARE
    v_existing_name Aquarium.nom%TYPE;
    nom Aquarium.nom%TYPE;
    taille Aquarium.taille%TYPE;

BEGIN
    -- V�rifier si l'aquarium existe d�j� dans la table
    SELECT nom INTO v_existing_name
    FROM Aquarium
    WHERE nom = :NEW.nom;
    
    
    IF v_existing_name IS NOT NULL THEN
        nom := :NEW.nom;
        taille := :NEW.taille;
        -- L'aquarium existe d�j�, mettez � jour sa taille au lieu d'ins�rer
        -- COMMIT ne peut pas �tre dans un trigger 
       UPDATEXIST(nom, taille); 
        -- Emp�cher l'insertion
        RAISE_APPLICATION_ERROR(-20001, 'Cet aquarium existe d�j�. Sa taille a �t� mise � jour.');
    END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    v_existing_name := NULL;
END;
/
insert into aquarium (nom, taille, date_creation) values ('aquapoisson', 145, '30/09/2022');
-------Exercice 5
CREATE OR REPLACE TRIGGER VerifierNomPoisson
BEFORE INSERT ON Poisson
FOR EACH ROW
DECLARE
    nom_aqua Aquarium.nom%TYPE;
BEGIN
    SELECT nom INTO nom_aqua
    FROM AQUARIUM
    WHERE id_aquarium = :NEW.id_aquarium;
    
    IF :NEW.id_aquarium = 3 AND NOT REGEXP_LIKE(:new.nom, '^Aqua', 'i')  THEN
        RAISE_APPLICATION_ERROR(-20001, 'Le nom du poisson doit commencer par "Aqua" pour l''aquarium ' || nom_aqua);
    END IF;
END;
INSERT INTO Poisson (Nom, Sexe, Date_Naissance, Id_Espece, Id_Aquarium) 
    VALUES ('uapo', 'M', '22/05/2008', 2, 3);