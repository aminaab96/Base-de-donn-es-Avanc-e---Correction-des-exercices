-------------------------Chapitre 6---------------------------------
-------Exercice 1
--------1)
--L'instruction COMMIT sert � enregistrer / stocker les modifications de transaction dans la base de donn�es, effectu�s pendant les op�rations DML, qui ne manipulent que les donn�es dans la m�moire tampon de la base de donn�es et la base de donn�es n'est pas affect�e par ces modifications.  
--------2)
--La diff�rence entre les deux insctructions c'est qu'apr�s l'instruction ROLLBACK, la transaction est compl�tement termin�e (c'est-�-dire que la commande ROLLBACK a compl�tement annul� une transaction et lib�r� tous les verrous).
--Tandis qu'apr�s la commande ROLLBACK TO, une transaction est toujours active et en cours d'ex�cution  car elle n'annule qu'une partie de la transaction jusqu'au SAVEPOINT donn�.
--------3)
--L'instruction SAVEPOINT donne un nom et marque un point dans le traitement de la transaction en cours. Les modifications et verrous qui se sont produits avant le SAVEPOINT dans la transaction sont conserv�s tandis que ceux qui se produisent apr�s le SAVEPOINT sont lib�r�s.
-------Exercice 2
--------1)
--Trois lignes.
--------2)
--Trois lignes.
--------3)
--Trois tables. En effet, les transactions n'affectent normalement que les instructions LMD et non les instructions LDD.
-------Exercice 3
--------1)
DECLARE
    es_nom_scientifique VARCHAR2(50) := 'Leptobotia elongata';
    es_nom_commun VARCHAR2(50) := 'Loche fleur imp�riale'; 
    es_description  VARCHAR2(50) := 'Leptobotia elongata est une race rare';
BEGIN
    INSERT INTO Espece (nom_scientifique, nom_commun, description) VALUES (es_nom_scientifique, es_nom_commun, es_description);  
    -- Utilisez COMMIT pour valider l'insertion
    COMMIT;  
    DBMS_OUTPUT.PUT_LINE('Insertion r�ussie et valid�e avec COMMIT.');
EXCEPTION
    WHEN OTHERS THEN
        -- G�rer les exceptions
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Erreur : ' || SQLERRM);
END;
--------2)
DECLARE
    i_aqua NUMBER := 4; -- L'ID de l'poisson que vous avez modifi�
    DATE_DONNEE DATE := SYSDATE; -- Date incorrecte
BEGIN
    -- Effectuer la mise � jour incorrecte
    UPDATE Aquarium SET date_creation = DATE_DONNEE WHERE id_aquarium = i_aqua; 
    -- Utilisez ROLLBACK pour annuler la mise � jour
    ROLLBACK;  
    DBMS_OUTPUT.PUT_LINE('Mise � jour annul�e avec ROLLBACK.');
EXCEPTION
    WHEN OTHERS THEN
        -- G�rer les exceptions
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Erreur : ' || SQLERRM);
END;
--------3)
DECLARE
    v_id_poisson NUMBER := 3; -- L'ID du poisson � mettre � jour
BEGIN
    -- Mettre � jour le poisson avec une sauvegarde apr�s chaque mise � jour
    UPDATE Poisson SET nom = 'Mise � jour 1' WHERE id_poisson = v_id_poisson;
    SAVEPOINT savepoint1;
    
    UPDATE Poisson SET nom = 'Mise � jour 2' WHERE id_poisson = v_id_poisson;
    SAVEPOINT savepoint2;
    
    UPDATE Poisson SET nom = 'Mise � jour 3' WHERE id_poisson = v_id_poisson;
    SAVEPOINT savepoint3;
    
    -- Simulation d'une erreur, revenir � savepoint2
    ROLLBACK TO savepoint2;
    
    DBMS_OUTPUT.PUT_LINE('Mise � jour annul�e jusqu''� savepoint2.');
EXCEPTION
    WHEN OTHERS THEN
        -- G�rer les exceptions
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Erreur : ' || SQLERRM);
END;
-------Exercice 4
CREATE OR REPLACE PROCEDURE Reservation (v_id_aquarium IN INTEGER,
                                      nb_places IN INT) 
AS
-- D�claration des variables
v_poisson INTEGER;
v_aquarium Aquarium%ROWTYPE;
v_places_libres INTEGER;
BEGIN
    -- On recherche l'aquarium
    SELECT * INTO v_aquarium
    FROM Aquarium WHERE id_aquarium=v_id_aquarium;   
    -- On recherche le nombre de poisson affect�s � cet aquarium
    SELECT COUNT(*) INTO v_poisson 
    FROM Poisson WHERE id_aquarium=v_id_aquarium; 
    
    v_places_libres := v_aquarium.taille - v_poisson;
    -- S'il reste assez de places: on effectue le transfert
    IF (v_places_libres >= nb_places) THEN
        -- Ins�rer tous les poissons conc�rn�s
            INSERT INTO Poisson (nom, sexe, date_naissance, id_aquarium, id_espece) VALUES ('v_nom_poisson', 'F', '01/01/2022', v_id_aquarium, 3); 
            DBMS_OUTPUT.PUT_LINE('Insertion de : ' || nb_places || ' de poissons valid�� !');
        -- Validation
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Pas assez de places libre dans l''aquarium : ' || v_aquarium.nom);
        ROLLBACK;
    END IF;
END Reservation;
DECLARE
    i_aqua NUMBER := 4;
    nombre_arrivage NUMBER := 2;
BEGIN
    Reservation(i_aqua,nombre_arrivage);
END;