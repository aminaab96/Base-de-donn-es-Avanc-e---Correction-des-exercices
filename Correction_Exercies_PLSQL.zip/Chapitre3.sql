-------------------------Chapitre 3---------------------------------
-------Exercice 1
--------1)
---Un curseur est un pointeur vers une zone SQL priv�e qui stocke des informations sur le traitement d'une instruction SELECT ou LMD comme INSERT, UPDATE, DELETE ou MERGE.
---Le curseur est un m�canisme qui vous permet d'attribuer un nom � une instruction SELECT et de manipuler les informations contenues dans cette instruction SQL.
---Chaque fois qu'une instruction LMD (INSERT, UPDATE et DELETE) est �mise, un curseur implicite est associ� � cette instruction. Pour les op�rations INSERT, le curseur contient les donn�es � ins�rer. Pour les op�rations UPDATE et DELETE, le curseur identifie les lignes qui seraient affect�es
--------2)
---Les curseurs SQL �tant automatiquement ferm�s apr�s l�ex�cution des instructions SQL qui leur sont associ�es, la fonction renvoie toujours FALSE pour les curseurs implicites.
--------3)
---FOUND, %ROWCOUNT, %OPEN et %NOTFOUND sont tous des attributs du curseur implicite
--------4)
---DECLARE
---Sur les instructions SELECT, les curseurs explicites retournent plus d�une ligne.
--------5)
---Il existe un moyen de manipuler le curseur et de laisser l'oracle faire le reste, en utilisant la boucle for
-------Exercice 2
--------1)
Create table poissons_par_aquarium (id NUMBER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1), nom_aquarium varchar2(50), nombre_poissons number(5)); 
--------2)
ACCEPT p_n PROMPT 'Entrer une valeur num�rique : '
DECLARE
  CURSOR emp_cursor IS
        SELECT A.Nom, A.taille, COUNT(P.id_poisson) AS Nombre_Poissons
        FROM aquarium A
        JOIN Poisson P ON A.id_aquarium = p.id_aquarium
        GROUP BY A.Nom, A.taille
        ORDER BY COUNT(P.id_poisson) DESC;
  emp_record emp_cursor%ROWTYPE;
BEGIN
    OPEN emp_cursor;
    FOR i IN 1..&p_n LOOP 
        FETCH emp_cursor INTO emp_record;
        INSERT INTO poissons_par_aquarium (nom_aquarium, nombre_poissons)
        VALUES (emp_record.nom,emp_record.Nombre_poissons);
    END LOOP;
    CLOSE emp_cursor;
    COMMIT;
END;
-------Exercice 3
ACCEPT p_n PROMPT 'Entrer une valeur num�rique : '
DECLARE
    MinPoissons NUMBER := &p_n;
    CURSOR AquariumCursor(MinPoissons NUMBER) IS
        SELECT Z.nom, COUNT(A.id_poisson) AS NombrePoissons
        FROM Aquarium Z
        LEFT JOIN Poisson A ON Z.id_aquarium = A.id_aquarium        
        GROUP BY Z.nom;
BEGIN
    FOR AquariumRow IN AquariumCursor(&p_n) LOOP
        IF AquariumRow.NombrePoissons < MinPoissons THEN
            DBMS_OUTPUT.PUT_LINE('L�aquarium ' || AquariumRow.nom || ' a moins de ' || MinPoissons || ' poissons.');
        END IF;
    END LOOP;
END;
-------Exercice 4
DECLARE 
    nombre_ligne NUMBER(2); 
    idespece NUMBER(2) ;
BEGIN
    SELECT id_espece INTO idespece 
    FROM ESPECE
    WHERE nom_scientifique = 'migrateurs';
    UPDATE Poisson
    SET Nom = CONCAT('senior',Nom)
    WHERE id_espece = idespece and EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM date_naissance)> 6;
    IF SQL%notfound THEN
        dbms_output.put_line('aucun poisson s�lectionn�'); 
    ELSIF SQL%found THEN
        nombre_ligne := SQL%rowcount;
    dbms_output.put_line( nombre_ligne || 'noms de poissons modifi�s '); 
   END IF;  
END;
-------Exercice 5
--------1)
DECLARE
    -- D�claration du curseur pour r�cup�rer les informations
    CURSOR PoissonCursor IS
        SELECT A.nom, 
               EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM A.date_naissance) AS age,
               E.nom_commun AS nom_commun_espece,
               E.nom_scientifique AS nom_scientifique_espece,
               Z.nom AS nom_aquarium
        FROM Poisson A
        JOIN Espece E ON A.id_espece = E.id_espece
        JOIN Aquarium Z ON A.id_aquarium = Z.id_aquarium;
    -- Variables pour stocker les informations
    NomPoisson VARCHAR2(100);
    Age NUMBER;
    NomCommunEspece VARCHAR2(100);
    NomScientifiqueEspece VARCHAR2(100);
    NomAquarium VARCHAR2(100);
BEGIN
    -- Ouverture du curseur
    OPEN PoissonCursor;
    -- Boucle WHILE pour afficher les informations de chaque poisson
   LOOP
        FETCH PoissonCursor INTO NomPoisson, Age, NomCommunEspece, NomScientifiqueEspece, NomAquarium;
        EXIT WHEN PoissonCursor%NOTFOUND; -- sortir si le curseur ne pointe sur aucune ligne
        DBMS_OUTPUT.PUT_LINE('Nom du poisson : ' || NomPoisson || ', �ge : ' || Age || ' ans, ' ||
                             'Nom commun de l''esp�ce : ' || NomCommunEspece || ', ' ||
                             'Nom scientifique de l''esp�ce : ' || NomScientifiqueEspece || ', ' ||
                             'Nom de l''aquarium : ' || NomAquarium);
    END LOOP;
    -- Fermeture du curseur
    CLOSE PoissonCursor;
END;
--------2)
DECLARE 
   CURSOR PoissonCursor IS
        SELECT A.nom, 
               EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM A.date_naissance) AS age,
               E.nom_commun AS nom_commun_espece,
               E.nom_scientifique AS nom_scientifique_espece,
               Z.nom AS nom_aquarium
        FROM Poisson A
        JOIN Espece E ON A.id_espece = E.id_espece
        JOIN Aquarium Z ON A.id_aquarium = Z.id_aquarium;
   record_poisson PoissonCursor%rowtype;
BEGIN
   FOR record_poisson IN PoissonCursor LOOP
        -- Traitements sur la ligne courante
        DBMS_OUTPUT.PUT_LINE('Nom du poisson : ' || record_poisson.nom || ', �ge : ' || record_poisson.age || ' ans, ' ||
                             'Nom commun de l''esp�ce : ' || record_poisson.nom_commun_espece || ', ' ||
                             'Nom scientifique de l''esp�ce : ' || record_poisson.nom_scientifique_espece || ', ' ||
                             'Nom de l''aquarium : ' || record_poisson.nom_aquarium);
   END LOOP;      
END;