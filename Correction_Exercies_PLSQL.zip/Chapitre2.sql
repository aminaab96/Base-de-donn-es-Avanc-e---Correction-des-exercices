-------------------------Chapitre 2---------------------------------
-------Exercice 1
--------1)
DECLARE
    -- D�clarez une variable pour stocker le nom scientifique de la nouvelle esp�ce
    NouveauNomScientifique VARCHAR2(100);
BEGIN
    -- G�n�rez un nom scientifique al�atoire (par exemple, en utilisant DBMS_RANDOM)
    -- Remarque : Vous pouvez personnaliser cette partie pour g�n�rer un nom scientifique al�atoire.
    SELECT 'NouvelleEspece_' || TO_CHAR(DBMS_RANDOM.VALUE(1000, 9999)) INTO NouveauNomScientifique FROM DUAL;
    -- Ins�rez la nouvelle esp�ce dans la table "Espece"
    INSERT INTO Espece (Nom_Scientifique, Nom_Commun, Description) VALUES (NouveauNomScientifique, 'NouveauNomCommun', 'Description de la nouvelle esp�ce');
END;
--------2)
DECLARE
    -- D�clarez des variables pour les donn�es de l'poisson
    NouveauNomPoisson VARCHAR2(50) := 'NouvelPoisson';
    SexePoisson CHAR(1) := 'F';
    DateNaissancePoisson DATE := TO_DATE('01/01/2023', 'DD/MM/YYYY');
    NomEspece VARCHAR2(100);
BEGIN
    -- Recherchez l'ID de la derni�re esp�ce ajout�e
    SELECT MAX(Id_Espece) INTO NomEspece FROM Espece;
    -- Ins�rez le nouveau poisson dans la table "Poisson" en l'affectant � la derni�re esp�ce ajout�e
    INSERT INTO Poisson (Nom, Sexe, Date_Naissance, Id_Espece, Id_Aquarium) 
    VALUES (NouveauNomPoisson, SexePoisson, DateNaissancePoisson, NomEspece, 1); -- Remplacez 1 par l'ID de l'aquarium appropri�
    COMMIT;
END;
--------3)
BEGIN
    FOR PoissonRow IN (SELECT Nom FROM Poisson WHERE Id_Espece = (SELECT Id_Espece FROM Espece WHERE espece.nom_scientifique = 'carnassiers')) LOOP
        DBMS_OUTPUT.PUT_LINE('Poisson : ' || PoissonRow.Nom);
    END LOOP;
END;
--------4)
BEGIN
    FOR AquariumRow IN (SELECT Nom FROM Aquarium) LOOP
        DBMS_OUTPUT.PUT_LINE('Aquarium : ' || AquariumRow.Nom);
    END LOOP;
END;
--------5)
-- Demandez � l'utilisateur de saisir l'ID de l'aquarium
ACCEPT Aquarium_ID PROMPT 'Veuillez saisir l''D de l''aquarium : '
DECLARE
    -- D�clarez une variable pour stocker l'ID de l'aquarium saisi par l'utilisateur
    AquariumID NUMBER := &Aquarium_ID; -- Utilisez & pour r�f�rencer la variable d�finie par ACCEPT
BEGIN
    -- Utilisez une requ�te SQL pour r�cup�rer les informations sur les esp�ces de l'aquarium
    FOR EspeceRow IN (
        SELECT E.Nom_Scientifique, E.Nom_Commun, COUNT(A.ID_Poisson) AS Nombre_Poissons
        FROM Espece E
        JOIN Poisson A ON E.ID_Espece = A.ID_Espece
        WHERE A.ID_Aquarium = AquariumID
        GROUP BY E.Nom_Scientifique, E.Nom_Commun
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Nom Scientifique : ' || EspeceRow.Nom_Scientifique);
        DBMS_OUTPUT.PUT_LINE('Nom Commun : ' || EspeceRow.Nom_Commun);
        DBMS_OUTPUT.PUT_LINE('Nombre de Poissons : ' || EspeceRow.Nombre_Poissons);
        DBMS_OUTPUT.PUT_LINE('----------------------');
    END LOOP;
END;
-------Exercice 2
--------1)
DECLARE
    -- Variables pour stocker les informations des esp�ces r�cup�r�es
    NouveauNomScientifique VARCHAR2(100);
    NouveauNomCommun VARCHAR2(100);
BEGIN
    -- Mise � jour de la taille du aquarium avec l'ID 4 � 400
    UPDATE Aquarium SET taille = 100 WHERE nom = 'aqualand';

    -- R�cup�ration des informations des esp�ces de cet aquarium
    FOR EspeceRow IN (SELECT nom_scientifique, nom_commun FROM Espece WHERE id_espece IN 
    (SELECT DISTINCT id_espece FROM Poisson WHERE id_aquarium = 
    (SELECT id_aquarium FROM Aquarium WHERE nom = 'aqualand' ))) LOOP
        NouveauNomScientifique := EspeceRow.nom_scientifique;
        NouveauNomCommun := EspeceRow.nom_commun;
        DBMS_OUTPUT.PUT_LINE('Nom scientifique : ' || NouveauNomScientifique || ', Nom commun : ' || NouveauNomCommun);
    END LOOP;
    
    COMMIT; -- Validez la transaction
END;
--------2)
DECLARE
    -- Variables pour le transfert de poissons
    ID_AquariumDestination NUMBER := 3; -- ID de l'aquarium de destination (ID 4 dans cet exemple)
BEGIN
    -- Cr�ez un bloc PL/SQL pour transf�rer des poissons depuis d'autres aquariums
    FOR AquariumSource IN (SELECT DISTINCT ID_Aquarium, ID_ESPECE FROM Poisson WHERE ID_Aquarium <> ID_AquariumDestination) LOOP
        FOR EspeceRow IN (SELECT E.ID_Espece, E.Nom_Scientifique FROM Espece E WHERE E.ID_ESPECE = AquariumSource.ID_ESPECE) LOOP
        DBMS_OUTPUT.PUT_LINE('Poissons de l''esp�ce ');
            -- V�rifiez si le nombre de poissons dans cette esp�ce est inf�rieur � 6
            DECLARE
                NombrePoissons INT;
            BEGIN
                SELECT COUNT(*) INTO NombrePoissons
                FROM Poisson A
                WHERE A.ID_Espece = EspeceRow.ID_Espece AND A.ID_Aquarium = AquariumSource.ID_Aquarium;
                
                IF NombrePoissons < 6 THEN
                    -- Transf�rez les poissons vers l�aquarium de destination (ID 4)
                    UPDATE Poisson SET ID_Aquarium = ID_AquariumDestination WHERE ID_Espece = EspeceRow.ID_Espece AND ID_Aquarium = AquariumSource.ID_Aquarium;
                    DBMS_OUTPUT.PUT_LINE('Poissons de l''esp�ce ' || EspeceRow.Nom_Scientifique || ' transf�r�s du aquarium ' || AquariumSource.ID_Aquarium || ' vers l�aquarium ' || ID_AquariumDestination);
                END IF;
            END;
        END LOOP;
    END LOOP;
    
    COMMIT; -- Validez la transaction
END;
BEGIN
ROLLBACK;
END;