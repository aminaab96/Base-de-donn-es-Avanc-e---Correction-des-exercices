-------------------------Chapitre 4---------------------------------
-------Exercice 1
--------1)
---les proc�dures sont utilis�es pour effectuer des t�ches et des op�rations sans renvoyer de valeur, tandis que les fonctions sont utilis�es pour effectuer des calculs ou des op�rations et renvoyer une valeur. Le choix entre les deux d�pend de l'objectif sp�cifique que vous souhaitez accomplir dans votre code PL/SQL.
---Les avantages des fonctions en PL/SQL c'est qu'ils permettent de r�utiliser le code, ce qui m�ne � un entretien facile, et garantissent �galement l�int�grit� des donn�es.
---
CREATE OR REPLACE FUNCTION nb_poisson(i_aqua IN Aquarium.id_aquarium%TYPE)
RETURN NUMBER
IS
NmbrePoisson NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO NmbrePoisson
    FROM Poisson;
    RETURN NmbrePoisson;
END nb_poisson;
CREATE OR REPLACE PROCEDURE nbd_poisson(i_aqua IN Aquarium.id_aquarium%TYPE, o_count OUT NUMBER)
IS
BEGIN
    SELECT COUNT(*) INTO o_count
    FROM Poisson
    WHERE id_aquarium = i_aqua;
END nbd_poisson;
DECLARE
    v_count NUMBER;
BEGIN
    --nbd_poisson(2, v_count);
    v_count := nb_poisson(2);
    DBMS_OUTPUT.PUT_LINE('Number of Fish: ' || v_count);
END;
-------Exercice 2
--------1)
CREATE OR REPLACE FUNCTION AgeMaximalEspece(
    IdEspece IN NUMBER)
    RETURN NUMBER
IS
    AgeMax NUMBER := 0;
BEGIN
    SELECT MAX(EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM date_naissance))
    INTO AgeMax
    FROM Poisson
    WHERE id_espece = IdEspece;
    RETURN AgeMax;
END AgeMaximalEspece;
--------2)
-- Demandez � l'utilisateur de saisir l'ID de l'espece
ACCEPT ESPECE_ID PROMPT 'Veuillez saisir l''D de l''espece : '
DECLARE
    EspeceID NUMBER := &ESPECE_ID;
    v_nb NUMBER;
    nom_espece VARCHAR(50);
BEGIN
    SELECT nom_scientifique INTO nom_espece
    FROM espece 
    WHERE id_espece = EspeceID;
    v_nb := AgeMaximalEspece(EspeceID);
    DBMS_OUTPUT.PUT_LINE('L''�ge maximale des poissos appartnenant � l''�spece ' || nom_espece || ' est :' || v_nb);
END;
-------Exercice 3
--------1)
CREATE OR REPLACE FUNCTION espece_par_aquarium(Aquarium_ID IN number)
RETURN number
IS
    nb number;
BEGIN
    SELECT COUNT(E.id_espece) AS NombreEspece INTO nb
    FROM Poisson A
    JOIN Espece E ON A.id_espece = E.id_espece
    JOIN Aquarium Z ON A.id_aquarium = Z.id_aquarium     
    WHERE Z.id_aquarium = Aquarium_ID;
    return nb;
END; 
--------2)
CREATE OR REPLACE PROCEDURE update_aquarium(idpoisson IN Poisson.id_poisson%type, i_aqua IN number)
IS
BEGIN
    UPDATE Poisson SET id_aquarium=i_aqua 
    WHERE id_poisson=idpoisson;
END update_aquarium;
ACCEPT p_n PROMPT 'Entrer l''ID du poisson : '
ACCEPT a_n PROMPT 'Entrer l''ID de l''aquarium : '
DECLARE
    idpoisson NUMBER := &p_n;
    i_aqua NUMBER := &a_n;
BEGIN
    update_aquarium(idpoisson, i_aqua);
END;
--------3)
CREATE OR REPLACE FUNCTION etat_aquarium(i_aqua IN number)
RETURN VARCHAR
IS 
    annee NUMBER;
BEGIN
    SELECT EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM date_creation)
    INTO annee
    FROM Aquarium
    WHERE id_aquarium = i_aqua;
    IF annee > 3 THEN
        RETURN 'N�cessite r�novation' ;
    ELSE
        RETURN 'Bon �tat';
    END IF;   
END etat_aquarium;
-- Demandez � l'utilisateur de saisir l'ID de l'aquarium
ACCEPT AQUA_ID PROMPT 'Veuillez saisir l''D de l''aquarium : '
DECLARE
    AQUAID NUMBER := &AQUA_ID;
    etat VARCHAR(50);
BEGIN
    etat := etat_aquarium(AQUAID);
    DBMS_OUTPUT.PUT_LINE(etat);
END;
--------4)
CREATE OR REPLACE FUNCTION AgeMoyenPoisson (espece Espece.nom_scientifique%type)
RETURN INTEGER
IS
moyen integer;
BEGIN
 SELECT AVG(id_poisson) INTO moyen
 FROM Poisson
 where id_espece = (SELECT id_espece
 FROM ESPECE 
 WHERE nom_scientifique = espece);
RETURN moyen;
END AgeMoyenPoisson;
-- Demandez � l'utilisateur de saisir le nom scientifique de l'espece
ACCEPT ES_NOM PROMPT 'Veuillez saisir le nom scientifique de l''espece :'
DECLARE
    nom_espece VARCHAR(50) := '&ES_NOM';
    agemoyen NUMBER; 
BEGIN

    agemoyen := AgeMoyenPoisson(nom_espece);
    DBMS_OUTPUT.PUT_LINE('L''age moyen de l''espece : ' || nom_espece || ' est : '|| agemoyen );
END;
--------5)
CREATE OR REPLACE FUNCTION POISSONS_APRES_08_2022 
RETURN INT
IS
NB INTEGER;
BEGIN
SELECT COUNT(*) INTO NB
FROM Poisson 
WHERE date_naissance > TO_DATE('31/08/2022', 'DD/MM/YYYY ');
RETURN NB;
END;
DECLARE
    nb NUMBER; 
BEGIN
    nb := POISSONS_APRES_08_2022;
    DBMS_OUTPUT.PUT_LINE('Il existe '|| nb || ' poissons qui sont n�s apr�s Ao�t 2022');
END;
--------5)
CREATE OR REPLACE PROCEDURE POISSONS_APRES_08_2022
AS
  LV_TEST_CUR SYS_REFCURSOR;
  NB NUMBER := 0;
BEGIN
    FOR LV_TEST_CUR IN (SELECT A.nom, 
            E.nom_scientifique AS nom_scientifique_espece,
            Z.nom AS nom_aquarium
            FROM Poisson A
            JOIN Espece E ON A.id_espece = E.id_espece
            JOIN Aquarium Z ON A.id_aquarium = Z.id_aquarium
            WHERE A.date_naissance > TO_DATE('31/08/2022', 'DD/MM/YYYY '))
    LOOP
    DBMS_OUTPUT.PUT_LINE(RPAD(LV_TEST_CUR.nom,10) || RPAD(LV_TEST_CUR.nom_scientifique_espece,30) || RPAD(LV_TEST_CUR.nom_aquarium,20));
    NB := NB+1;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Il existe '|| NB || ' poissons qui sont n�s apr�s Ao�t 2022');
END myprocedure;
DECLARE
    nb NUMBER; 
BEGIN
    myprocedure;
END;