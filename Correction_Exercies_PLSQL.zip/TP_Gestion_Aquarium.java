package net.codejava;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Exercice_1 {
	

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
        try {
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","orcl","orcl");
            // Exercice 1
            /*
            Statement statement = connection.createStatement();
            System.out.println("Connect�e");
            //ResultSet resultSet = statement.executeQuery("SELECT nom, taille, date_creation FROM Aquarium");

            while (resultSet.next()) {
                //System.out.println(resultSet.getString("nom"));
                System.out.format("%s%10d%30s", resultSet.getString("nom"), resultSet.getInt("taille"), resultSet.getString("date_creation"));
                System.out.println();
            } */
         // Exercice 2
         /*
         // Requ�te SQL pour obtenir le nombre total d'animaux dans l�aquarium sp�cifi�
            Scanner sc = new Scanner(System.in);
            System.out.println ("Entrez le nom du aquarium") ;
            String aquariumName =  sc.nextLine() ;
            String sqlQuery = "SELECT COUNT(*) FROM Poisson WHERE id_aquarium = (SELECT id_aquarium FROM Aquarium WHERE nom = ?)";

            // Cr�er une instruction pr�par�e
            PreparedStatement statement = connection.prepareStatement(sqlQuery);
            statement.setString(1, aquariumName);

            // Ex�cuter la requ�te SQL et obtenir le r�sultat
            ResultSet resultSet = statement.executeQuery();

            // R�cup�rer le nombre total d'animaux
            if (resultSet.next()) {
                int poissonCount = resultSet.getInt(1);
                System.out.println("Nombre total de poissons dans l'aquarium " +aquariumName+ " est : " + poissonCount );
            } */
         // Exercice 3
            /*
            Scanner sc = new Scanner(System.in);
            System.out.println ("Entrez l'ID de l'aquarium") ;
            int aquariumID =  sc.nextInt() ;
            PreparedStatement statement = connection.prepareStatement("UPDATE Aquarium SET taille = 500 WHERE id_aquarium = ? AND taille < 500");
            statement.setInt(1, aquariumID);

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Aquarium size updated.");
            } else {
                System.out.println("Aquarium size is already 500 or more.");
            }*/
         // Exercice 4
            /*
            Scanner sc = new Scanner(System.in);
            System.out.println ("Entrez l'ID de l'aquarium") ;
            int aquariumID =  sc.nextInt() ;
            PreparedStatement statement = connection.prepareStatement("SELECT AVG(EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM date_naissance)) AS avg_age FROM Poisson WHERE id_aquarium = ?");
            statement.setInt(1, aquariumID);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                double avgAge = resultSet.getDouble("avg_age");
                System.out.println("Average Age of Poissons: " + avgAge);
            }*/
            // Exercice 5
            /*
            // Poisson details
            String name = "AquaFish";
            int taille = -40;
            String date_creation = "31/08/2023";

            // SQL query to insert a new aquarium
            String sqlInsert = "INSERT INTO Aquarium (nom, taille, date_creation) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sqlInsert);
            statement.setString(1, name);
            statement.setInt(2, taille);
            statement.setString(3, date_creation);

            // Attempt to insert the aquarium
            statement.executeUpdate();

            System.out.println("Aquarium inserted successfully."); */
            // Exercice 6 
            /*
            Statement statement = connection.createStatement();
            statement.execute("CREATE OR REPLACE TRIGGER Espece_NomScientifique_Audit BEFORE UPDATE ON Espece " //
                + "FOR EACH ROW "//
                + "DECLARE " //
                + "v_nom_scientifique_avant VARCHAR2(255); "//
                + "BEGIN "//
                + "SELECT nom_scientifique INTO v_nom_scientifique_avant "//
                + "FROM Espece "//
                + "WHERE id_espece = :OLD.id_espece; "//
                + "INSERT INTO AuditEspece (id_espece, nom_scientifique_avant, nom_scientifique_apres, date_audit) "//
                + "VALUES (:OLD.id_espece, v_nom_scientifique_avant, :NEW.nom_scientifique, SYSDATE); "//
                + "END;");*/
            // Exercice 8
            /*
            Scanner scanner = new Scanner(System.in);


            System.out.print("Entrer nom du poisson : ");
            scanner.nextLine(); // Consume the newline character
            String poissonName = scanner.nextLine();
            
            System.out.print("Entrer le sexe du poisson: ");
            String poissonSexe = scanner.nextLine();
            
            System.out.print("Entrer la date de naissance du poisson: ");
            String poissondateN = scanner.nextLine();

            System.out.print("Entrer Espece ID: ");
            int especeId = scanner.nextInt();
            
            System.out.print("Entrer Aquarium ID: ");
            int aquariumId = scanner.nextInt();

            // Call the AddNewPoisson procedure
            String procedureCall = "{ call AddNewPoisson(?, ?, ?, ?, ?) }";
            try (PreparedStatement preparedStatement = connection.prepareCall(procedureCall)) {
                preparedStatement.setString(1, poissonName);
                preparedStatement.setString(2, poissonSexe);
                preparedStatement.setString(3, poissondateN);
                preparedStatement.setInt(4, especeId);
                preparedStatement.setInt(5, aquariumId);
                preparedStatement.execute();
                System.out.println("Poisson ajout� avec succ�s.");
            }*/
            // Exercice 9
            
            
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Aquarium ID: ");
            int aquariumId = scanner.nextInt();

            // Call the GetTotalPoissonsInAquarium function
            String functionCall = "{ ? = call GetTotalPoissonsInAquarium(?) }";
            try (CallableStatement callableStatement = connection.prepareCall(functionCall)) {
                callableStatement.registerOutParameter(1, java.sql.Types.NUMERIC);
                callableStatement.setInt(2, aquariumId);
                callableStatement.execute();
                int totalPoissons = callableStatement.getInt(1);
                System.out.println("Total Poissons in Aquarium " + aquariumId + ": " + totalPoissons);
            }



            //resultSet.close();
            //statement.close();
            //connection.close();
        } catch (SQLException e) {
        	if (e.getErrorCode() == 20001) {
                System.err.println("Erreur: Taille aquarium ne peut pas �tre negative.");
            } else {
                e.printStackTrace();}

        }
	} 
}


