SET SERVEROUTPUT ON;
-------------------------Chapitre 1---------------------------------
-------Exercice 2
DECLARE
TYPE PoissonRecord IS RECORD (
    ID_Poisson Poisson.id_poisson%TYPE,
    Nom Poisson.nom%TYPE,
    Sexe Poisson.sexe%TYPE,
    Date_Naissance Poisson.date_naissance%TYPE,
    ID_Espece Poisson.id_espece%TYPE,
    ID_Aquarium Poisson.id_aquarium%TYPE
);
    -- Cr�ez un record "Poisson"
    Poisson1 PoissonRecord;
BEGIN
    -- Utilisez une boucle FOR pour parcourir tous les enregistrements de la table "Poisson"
    FOR PoissonRow IN (SELECT * FROM Poisson) LOOP
        Poisson1.ID_Poisson:= PoissonRow.id_poisson;
        Poisson1.Nom := PoissonRow.Nom;
        Poisson1.Sexe := PoissonRow.Sexe;
        Poisson1.Date_Naissance := PoissonRow.Date_Naissance;
        Poisson1.ID_Espece := PoissonRow.ID_Espece;
        Poisson1.ID_Aquarium := PoissonRow.ID_Aquarium;
        DBMS_OUTPUT.PUT_LINE('ID_Poisson : ' || Poisson1.ID_Poisson);
        DBMS_OUTPUT.PUT_LINE('Nom : ' || Poisson1.Nom);
        DBMS_OUTPUT.PUT_LINE('Sexe : ' || Poisson1.Sexe);
        DBMS_OUTPUT.PUT_LINE('Date de Naissance : ' || TO_CHAR(Poisson1.Date_Naissance, 'DD/MM/YYYY'));
        DBMS_OUTPUT.PUT_LINE('ID_Espece : ' || Poisson1.ID_Espece);
        DBMS_OUTPUT.PUT_LINE('ID_Aquarium : ' || Poisson1.ID_Aquarium);
        DBMS_OUTPUT.PUT_LINE('----------------------');
    END LOOP;
END;
-------Exercice 3
DECLARE
    -- Cr�ez un tableau VARRAY de type INT pour le nombre d'animaux par esp�ce
    TYPE NombrePoissonsParEspece IS VARRAY(100) OF INT;
    PoissonsParEspece NombrePoissonsParEspece := NombrePoissonsParEspece();
    -- Cr�ez un tableau VARRAY de type VARCHAR pour les noms scientifiques des esp�ces
    TYPE NomsScientifiquesEspece IS VARRAY(100) OF VARCHAR2(100);
    NomsEspece NomsScientifiquesEspece := NomsScientifiquesEspece();
    -- Initialisez l'indice de la boucle
    i NUMBER := 1;
BEGIN
    PoissonsParEspece := NombrePoissonsParEspece(12, 5, 17, 18);
    NomsEspece := NomsScientifiquesEspece('salmonides', 'carnassiers', 'migrateurs','cyprinid�s');
    -- Affichez le total des esp�ces et les informations sur chaque esp�ce
    DBMS_OUTPUT.PUT_LINE('Total des esp�ces : ' || NomsEspece.COUNT);

    FOR i IN 1..NomsEspece.COUNT LOOP
        DBMS_OUTPUT.PUT_LINE('Nom Scientifique : ' || NomsEspece(i));
        DBMS_OUTPUT.PUT_LINE('Nombre de Poissons : ' || PoissonsParEspece(i));
        DBMS_OUTPUT.PUT_LINE('----------------------');
    END LOOP;
    -- Utilisez une boucle WHILE pour parcourir les informations sur chaque esp�ce
    WHILE i <= NomsEspece.COUNT LOOP
        -- V�rifiez si le nombre d'animaux par esp�ce est inf�rieur � 6
        IF PoissonsParEspece(i) < 6 THEN
            -- Affichez le message
            DBMS_OUTPUT.PUT_LINE('Nous avons moins de 6 poissons appartenant � l''esp�ce : ' || NomsEspece(i));
        END IF;
        -- Incr�mentez l'indice de la boucle
        i := i + 1;
    END LOOP;
END;